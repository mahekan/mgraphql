# mgraphql
Python library link with graphql
